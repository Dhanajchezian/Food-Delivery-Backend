package model.services;

import java.util.List;
import model.entities.FoodItem;
import model.entities.Order;

public class OrderService {

    public static Order createOrder(int orderId, List<FoodItem> items) {
        double total = 0;
        for (FoodItem item : items) {
            total += item.getPrice();
        }
        return new Order(orderId, items, total);
    }
}
