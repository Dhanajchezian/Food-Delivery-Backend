package model.services;

import model.threads.OrderProcessor;

public class ThreadManager {

    public static void startThreads() {
        Thread orderThread = new Thread(new OrderProcessor());
        orderThread.start();
    }
}
