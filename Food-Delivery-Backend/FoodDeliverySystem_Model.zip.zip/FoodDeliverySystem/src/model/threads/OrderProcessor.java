package model.threads;

import model.queue.OrderQueue;
import model.entities.Order;
import model.enums.Orderstatus;

public class OrderProcessor implements Runnable {

    @Override
    public void run() {
        while (true) {
            try {
                Order order = OrderQueue.getOrder();
                order.setStatus(Orderstatus.PROCESSING);
                Thread.sleep(2000);
                order.setStatus(Orderstatus.PREPARED);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
