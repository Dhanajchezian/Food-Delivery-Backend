package model.entities;

import java.util.List;
import model.enums.Orderstatus;

public class Order {
    private int orderId;
    private List<FoodItem> items;
    private double totalAmount;
    private Orderstatus status;

    public Order(int orderId, List<FoodItem> items, double totalAmount) {
        this.orderId = orderId;
        this.items = items;
        this.totalAmount = totalAmount;
        this.status = Orderstatus.PLACED;
    }

    public void setStatus(Orderstatus status) {
        this.status = status;
    }

    public Orderstatus getStatus() {
        return status;
    }
}
