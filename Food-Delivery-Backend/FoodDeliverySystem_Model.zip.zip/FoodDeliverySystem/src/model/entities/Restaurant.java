package model.entities;

public class Restaurant {
    private int restaurantId;
    private String name;
    private boolean isOpen;

    public Restaurant(int restaurantId, String name, boolean isOpen) {
        this.restaurantId = restaurantId;
        this.name = name;
        this.isOpen = isOpen;
    }

    public boolean isOpen() {
        return isOpen;
    }
    
    public int getrestid() {
    	return restaurantId;
    }
    
    public String getrestname() {
    	return name;
    }
}
