package model.queue;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import model.entities.Order;

public class OrderQueue {
    private static BlockingQueue<Order> queue = new LinkedBlockingQueue<>();

    public static void addOrder(Order order) {
        queue.add(order);
    }

    public static Order getOrder() throws InterruptedException {
        return queue.take();
    }
}
