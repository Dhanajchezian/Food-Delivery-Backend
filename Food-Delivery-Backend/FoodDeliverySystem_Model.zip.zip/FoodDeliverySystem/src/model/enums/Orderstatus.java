package model.enums;

public enum Orderstatus {
    PLACED,
    QUEUED,
    PROCESSING,
    PREPARED,
    OUT_FOR_DELIVERY,
    DELIVERED,
    CANCELLED
}
